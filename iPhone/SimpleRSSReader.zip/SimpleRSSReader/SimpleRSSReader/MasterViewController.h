//
//  MasterViewController.h
//  SimpleRSSReader
//
//  Created by 松下 浩則 on 2012/11/26.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController <NSXMLParserDelegate>

@property (weak, nonatomic) IBOutlet UIBarButtonItem *setButton;
@property (weak, nonatomic) IBOutlet UITextField *urlTextField;
- (IBAction)setURL:(id)sender;

// データを読み込むメソッド
- (NSArray *)loadData:(NSString *)urlString;

- (IBAction)closeKeyboard:(id)sender;

// XMLを読み込み解析するメソッド
- (NSMutableArray *)loadXML:(NSString *)urlString;

@end
