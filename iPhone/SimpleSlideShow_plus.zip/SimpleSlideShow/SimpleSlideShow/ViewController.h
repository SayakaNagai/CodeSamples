//
//  ViewController.h
//  SimpleSlideShow
//
//  Created by 松下 浩則 on 2012/11/21.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate>

// プロパティmainImageの宣言
@property(weak,nonatomic) IBOutlet UIImageView *mainImage;

@property (weak, nonatomic) IBOutlet UIButton *showButton;
- (IBAction)showImage:(id)sender;
- (IBAction)hidePicker:(id)sender;
@property (weak, nonatomic) IBOutlet UIPickerView *imagePicker;
@property (weak, nonatomic) IBOutlet UIButton *nextButton;
- (IBAction)nextImage:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *timerButton;
- (IBAction)startTimer:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *prevButton;
- (IBAction)prevImage:(id)sender;

@end
