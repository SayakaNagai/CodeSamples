package jp.kagen.simplephotoalbum;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class PhotoDBHelper extends SQLiteOpenHelper {

	public PhotoDBHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase arg0) {
		// TODO Auto-generated method stub
		// �e�[�u��photo_table�̒�`
		String sql = "create table photo_table"
			+ "(photo_id integer primary key autoincrement,"
			+ " photo_file text,"
			+ " photo_title text,"
			+ " photo_rating float)";
		// �e�[�u���̍쐬
		arg0.execSQL(sql);
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub

	}

}
