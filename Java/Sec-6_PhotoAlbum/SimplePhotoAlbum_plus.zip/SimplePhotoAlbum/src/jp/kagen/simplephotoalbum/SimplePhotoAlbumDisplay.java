package jp.kagen.simplephotoalbum;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class SimplePhotoAlbumDisplay extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		// ���C�A�E�g�̃Z�b�g
		setContentView(R.layout.display);
	
		// �p�����[�^�̎��o��
		Intent intent = getIntent();
		int id = intent.getIntExtra("id", 0);
		String file = intent.getStringExtra("file");
		String title = intent.getStringExtra("title");
		float rating = intent.getFloatExtra("rating", 0);
		
		// �摜�̕\��
		ImageView imageViewDisplay = (ImageView)findViewById(R.id.ImageViewDisplay);
		Bitmap bitmap = BitmapFactory.decodeFile(file);
		imageViewDisplay.setImageBitmap(bitmap);

		// �^�C�g���̕\��
		TextView textViewDisplay = (TextView)findViewById(R.id.TextViewDisplay);
		textViewDisplay.setText(title);
		
		// �]���̕\��
		RatingBar ratingBarDisplay = (RatingBar)findViewById(R.id.RatingBarDisplay);
		ratingBarDisplay.setRating(rating);		

	}

	public void closeActivity(View view){
		// �\����ʂ����
		finish();
	}
}
