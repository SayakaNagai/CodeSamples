//
//  MasterViewController.m
//  SimpleRSSReader
//
//  Created by 松下 浩則 on 2012/11/26.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import "MasterViewController.h"

#import "DetailViewController.h"

@interface MasterViewController () {
    NSMutableArray *_objects;
}
@end

@implementation MasterViewController {
    // title要素を格納する配列
    NSMutableArray *titleArray;
    // item要素のチェック
    BOOL itemElementCheck;
    // title要素のチェック
    BOOL titleElementCheck;
    // title要素のテキスト
    NSString *titleText;
    // link要素を格納する配列
    NSMutableArray *linkArray;
    // link要素のチェック
    BOOL linkElementCheck;
    // link要素のテキスト
    NSString *linkText;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    /*
    self.navigationItem.leftBarButtonItem = self.editButtonItem;

    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(insertNewObject:)];
    self.navigationItem.rightBarButtonItem = addButton;
    */
    
    // データの初期値をセット
    //_objects = [NSMutableArray arrayWithObjects:@"ねずみ",@"うし",@"とら",@"うさぎ", nil];
    _objects = [NSMutableArray array];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)insertNewObject:(id)sender
{
    if (!_objects) {
        _objects = [[NSMutableArray alloc] init];
    }
    [_objects insertObject:[NSDate date] atIndex:0];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _objects.count;
    // データ件数３
    //return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];

    // NSDate *object = _objects[indexPath.row];
    // cell.textLabel.text = [object description];
    
    // データの指定
    /*
     if (indexPath.row == 0) {
        cell.textLabel.text = @"ねずみ";
    } else if (indexPath.row == 1) {
        cell.textLabel.text = @"うし";
    } else {
        cell.textLabel.text = @"とら";
    }
    */
    cell.textLabel.text = _objects[indexPath.row];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [_objects removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }
}

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        //NSDate *object = _objects[indexPath.row];
        
        // 選択されたリンク先を変数objectに代入
        NSString *object = linkArray[indexPath.row];

        [[segue destinationViewController] setDetailItem:object];
    }
}

// URLをセットするメソッド
- (IBAction)setURL:(id)sender {
    // 入力ボックスに入力された値を配列に追加
    //[_objects addObject:_urlTextField.text];
    
    // 読み込んだデータを配列にセット
    //[_objects setArray:[self loadData:_urlTextField.text]];
    [_objects setArray:[self loadXML:_urlTextField.text]];
    
    // テーブビューを再読み込み
    [self.tableView reloadData];
}

// データを読み込むメソッド
- (NSArray *)loadData:(NSString *)urlString {
    // URLを作成
    NSURL *url = [NSURL URLWithString:urlString];
    
    // URLからUTF-8文字列のデータを取得
    NSString *data = [NSString stringWithContentsOfURL:url
                                              encoding:NSUTF8StringEncoding
                                                 error:NULL];
    // 改行で分割して配列に格納
    NSArray *dataArray = [data componentsSeparatedByString:@"\n"];
    
    // 配列を返す
    return dataArray;
}

// キーボードを閉じる
- (IBAction)closeKeyboard:(id)sender {
    [sender resignFirstResponder];
}

// XMLを読み込み解析するメソッド
- (NSMutableArray *)loadXML:(NSString *)urlString {
    // 変数の初期化
    titleArray = [NSMutableArray array];
    itemElementCheck = NO;
    titleElementCheck = NO;
    titleText = @"";
    linkArray = [NSMutableArray array];
    linkElementCheck = NO;
    linkText = @"";
    
    // URLを作成
    NSURL *url = [NSURL URLWithString:urlString];
    
    // URLからパーサーを作成
    NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:url];
    
    // デリゲートをセット
    [parser setDelegate:self];
    
    // XMLを解析
    [parser parse];

    // 配列を返す
    return titleArray;
}

// 開始タグの処理
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    // item要素のチェック
    if ([elementName isEqualToString:@"item"]) {
        itemElementCheck = YES;
    }
    
    // title要素のチェック
    if (itemElementCheck && [elementName isEqualToString:@"title"]) {
        titleElementCheck = YES;
    } else {
        titleElementCheck = NO;
    }
    
    // link要素のチェック
    if (itemElementCheck && [elementName isEqualToString:@"link"]) {
        linkElementCheck = YES;
    } else {
        linkElementCheck = NO;
    }
}

// 終了タグの処理
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    // item要素のチェック
    if ([elementName isEqualToString:@"item"]) {
        itemElementCheck = NO;
    }
    
    // title要素のチェック
    if ([elementName isEqualToString:@"title"]) {
        if (titleElementCheck) {
            // 配列titleArrayに追加
            [titleArray addObject:titleText];
        }
        // titleElementCheckをNO、titleTextを空にセット
        titleElementCheck = NO;
        titleText = @"";
    }
    
    // link要素のチェック
    if ([elementName isEqualToString:@"link"]) {
        if (linkElementCheck) {
            // 配列linkArrayに追加
            [linkArray addObject:linkText];
        }
        // linkElementCheckをNO、linkTextを空にセット
        linkElementCheck = NO;
        linkText = @"";
    }
}

// テキストの取り出し
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    // titleテキストの取り出し
    if (titleElementCheck) {
        titleText = [titleText stringByAppendingString:string];
    }
    
    // linkテキストの取り出し
    if (linkElementCheck) {
        linkText = [linkText stringByAppendingString:string];
    }
}

@end
