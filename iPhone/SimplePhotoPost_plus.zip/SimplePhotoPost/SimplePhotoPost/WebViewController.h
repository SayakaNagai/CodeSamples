//
//  WebViewController.h
//  SimplePhotoPost
//
//  Created by 松下 浩則 on 2012/12/04.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *webView;
- (IBAction)closeView:(id)sender;

// URLを受け取るプロパティの宣言
@property (weak, nonatomic) NSString *stringURL;

@end
