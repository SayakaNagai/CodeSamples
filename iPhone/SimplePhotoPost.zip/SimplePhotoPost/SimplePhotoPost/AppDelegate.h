//
//  AppDelegate.h
//  SimplePhotoPost
//
//  Created by 松下 浩則 on 2012/12/04.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
