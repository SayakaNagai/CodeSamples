//
//  ViewController.m
//  SimplePhotoPost
//
//  Created by 松下 浩則 on 2012/12/04.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController {
    // 選択された画像を格納する変数を宣言
    UIImage *selectedImage;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// キーボードを閉じるメソッド
- (IBAction)closeKeyboard:(id)sender {
    [sender resignFirstResponder];
}

// 投稿画面を表示するメソッド
- (IBAction)showPostView:(id)sender {
    // 投稿画面の種類を格納する変数
    NSString *viewType;
    
    // 投稿画面の種類をセット
    if ([sender tag] == 0) {
        viewType = SLServiceTypeFacebook;
    } else {
        viewType = SLServiceTypeTwitter;
    }
    
    // 投稿画面の生成
    SLComposeViewController *postView = [SLComposeViewController composeViewControllerForServiceType:viewType];
    
    // 入力された投稿をセット
    [postView setInitialText:_postTextField.text];
    
    // 選択された画像をセット
    [postView addImage:selectedImage];
    
    // 投稿画面の表示
    [self presentViewController:postView animated:YES completion:nil];
}

// 保存されている画像を選択するメソッド
- (IBAction)pickImage:(id)sender {
    // 画像選択画面の生成
    UIImagePickerController *pickerView = [[UIImagePickerController alloc] init];
    
    // ソースタイプにPhotoLibraryをセット
    [pickerView setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    
    // デリゲートをセット
    [pickerView setDelegate:self];
    
    // 画像選択画面の表示
    [self presentViewController:pickerView animated:YES completion:nil];    
}

- (IBAction)clearImage:(id)sender {
    // 選択された画像を空にする
    selectedImage = nil;
    // Image Viewに選択された画像をセット
    [_postImage setImage:selectedImage];
}

// 画像が選択されたときの処理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    // 変数selectedImageに選択された画像を代入
    selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    // Image Viewに選択された画像をセット
    [_postImage setImage:selectedImage];
    
    // 画像選択画面を閉じる
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // URLを格納する変数
    NSString *url;
    // セグエによってセットするURLを切り替える
    if ([[segue identifier] isEqualToString:@"segueFB"]) {
        url = @"http://www.facebook.com";
    } else {
        url = @"https://twitter.com";
    }
    
    // 遷移先の画面の呼び出し
    WebViewController *webViewController = (WebViewController *)[segue destinationViewController];

    // プロパティstringURLにURLをセット
    webViewController.stringURL = url;
}

@end
