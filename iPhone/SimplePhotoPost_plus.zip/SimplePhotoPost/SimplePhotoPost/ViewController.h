//
//  ViewController.h
//  SimplePhotoPost
//
//  Created by 松下 浩則 on 2012/12/04.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Social/Social.h>
#import "WebViewController.h"

@interface ViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *postTextField;
- (IBAction)closeKeyboard:(id)sender;
- (IBAction)showPostView:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *postImage;
- (IBAction)pickImage:(id)sender;

- (IBAction)clearImage:(id)sender;

@end
