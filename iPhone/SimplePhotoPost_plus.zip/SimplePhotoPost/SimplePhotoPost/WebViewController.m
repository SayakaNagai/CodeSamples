//
//  WebViewController.m
//  SimplePhotoPost
//
//  Created by 松下 浩則 on 2012/12/04.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController ()

@end

@implementation WebViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    // URLを作成
    NSURL *url = [NSURL URLWithString:_stringURL];
    // リクエストを作成
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    // ページを表示
    [_webView loadRequest:request];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 画面を閉じるメソッド
- (IBAction)closeView:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
