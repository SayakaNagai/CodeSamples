//
//  ViewController.m
//  SimpleSlideShow
//
//  Created by 松下 浩則 on 2012/11/21.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
    // リソース画像のファイル名を格納する配列imageArrayの宣言
    NSArray *imageArray;
    // 選択されている画像の位置を格納する変数selectedImageの宣言
    NSInteger selectedImage;
    // タイマーを扱う変数timerの宣言
    NSTimer *timer;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // 変数_mainImageにリソース画像を指定
    // _mainImage.image = [UIImage imageNamed:@"sample.jpg"];
    
    // 配列imageArrayにリソース画像のファイル名をセット
    imageArray = [NSArray arrayWithObjects:
                  @"sample.jpg",@"sample2.jpg",@"sample3.jpg", nil];
    // 変数selectedImageの初期値を0（先頭画像）にセット
    selectedImage = 0;    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 画像を表示するメソッド
- (IBAction)showImage:(id)sender {
    // 変数_mainImageにリソース画像を指定
    _mainImage.image = [UIImage imageNamed:@"sample.jpg"];
}

// Pickerを隠す／表示するメソッド
- (IBAction)hidePicker:(id)sender {
    // Pickerの透明度を調べる
    if (_imagePicker.alpha == 1.0f) {
        // Pickerを隠す（透明にする）
        _imagePicker.alpha = 0.0f;
        // ボタンのラベルをShow Pickerに変更する
        [_showButton setTitle:@"Show Picker"
                     forState:UIControlStateNormal];
    } else {
        // Pickerを表示する（不透明にする）
        _imagePicker.alpha = 1.0f;
        // ボタンのラベルをHide Pickerに変更する
        [_showButton setTitle:@"Hide Picker"
                     forState:UIControlStateNormal];
    }
}

// UIPickerViewDataSourceのメソッド
// コンポーネント数の指定
- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    // コンポーネントの数は１
    return 1;
}

// 要素数の指定
- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    // 要素の数は３
    return 3;
}

// UIPickerViewDelegateのメソッド
// 表示する要素の指定
- (NSString*) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    // 文字列testを表示
    // return @"test";
    // 配列の中身を表示
    return [imageArray objectAtIndex:row];
}

// 要素が選択されたときの動作
- (void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    // 変数_mainImageに選択されたリソース画像を指定
    _mainImage.image = [UIImage imageNamed:
                        [imageArray objectAtIndex:row]];
}

// 次の画像を表示するメソッド
- (IBAction)nextImage:(id)sender {
    // 選択位置を１増やす
    selectedImage++;
    
    // 選択位置が末尾を超えた場合
    if (selectedImage == [imageArray count]) {
        // 先頭（0）に戻す
        selectedImage = 0;
    }
    
    // Pickerの選択位置を変更
    [_imagePicker selectRow:selectedImage inComponent:0 animated:YES];
    
    // 画像を表示
    _mainImage.image =[UIImage imageNamed:
                       [imageArray objectAtIndex:selectedImage]];
}

// タイマーを開始／停止するメソッド
- (IBAction)startTimer:(id)sender {
    // タイマーが動いているかどうかを調べる
    if ([timer isValid]) {
        // タイマーを停止する
        [timer invalidate];
        timer = nil;
        
        // ボタンのラベルをStartに変更する
        [_timerButton setTitle:@"Start" forState:UIControlStateNormal];
    } else {
        // タイマーを作成＋開始する
        timer = [NSTimer scheduledTimerWithTimeInterval:10.0
                                                 target:self
                                               selector:@selector(nextImage:)
                                               userInfo:nil
                                                repeats:YES];
        // ボタンのラベルをStopに変更する
        [_timerButton setTitle:@"Stop" forState:UIControlStateNormal];
    }
}

// 前の画像を表示するメソッド
- (IBAction)prevImage:(id)sender {
    // 選択位置を１減らす
    selectedImage--;
    
    // 選択位置が-1になった場合
    if (selectedImage == -1) {
        // 最後尾（要素数-1）に移動
        selectedImage = [imageArray count]-1;
    }
    
    // Pickerの選択位置を変更
    [_imagePicker selectRow:selectedImage inComponent:0 animated:YES];
    
    // 画像を表示
    _mainImage.image =[UIImage imageNamed:
                       [imageArray objectAtIndex:selectedImage]];
}
@end
