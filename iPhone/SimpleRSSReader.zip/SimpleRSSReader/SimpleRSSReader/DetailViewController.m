//
//  DetailViewController.m
//  SimpleRSSReader
//
//  Created by 松下 浩則 on 2012/11/26.
//  Copyright (c) 2012年 オフィス加減. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
- (void)configureView;
@end

@implementation DetailViewController

#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem
{
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        // Update the view.
        [self configureView];
    }
}

- (void)configureView
{
    // Update the user interface for the detail item.

    if (self.detailItem) {
        self.detailDescriptionLabel.text = [self.detailItem description];
        
        // リンク先からURLを作成
        NSURL *url = [NSURL URLWithString:self.detailItem];
        // URLからリクエストを作成
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        // リクエストを読み込みWebページを表示
        [_rssWeb loadRequest:request];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self configureView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
